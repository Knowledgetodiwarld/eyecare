# Evolve Beyond Religion

A philosophical project and web platform to inspire critical thinking and a secular evolution of consciousness.